# Simple Open EtherCAT Master Library

* Copyright (C) 2005-2025 Speciaal Machinefabriek Ketels v.o.f.
* Copyright (C) 2005-2025 Arthur Ketels
* Copyright (C) 2009-2025 RT-Labs AB, Sweden

# License

This software is dual-licensed.

## GPL version 3

This software is distributed under GPLv3. You are allowed to use this
software for an open-source project with a compatible license.

[GNU GPL license v3](https://www.gnu.org/licenses/gpl-3.0.html)

## Commercial license

This software is also available under a commercial license with
options for support and maintenance. Please contact sales@rt-labs.com
for further details.

If you intend to use this stack in a commercial product, you likely need to
buy a license.
